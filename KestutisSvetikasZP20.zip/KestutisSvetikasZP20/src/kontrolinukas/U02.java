package kontrolinukas;

public class U02 {

    public static void main(String[] args) {

        AlgoritmaiKestutis.masyvai2();



    }
}
