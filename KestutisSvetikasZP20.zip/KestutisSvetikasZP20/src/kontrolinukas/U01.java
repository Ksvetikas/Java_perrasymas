package kontrolinukas;

public class U01 {

    public static void main(String[] args) {

        System.out.println("Kiek noretumete isspausdinti zvaigzduciu.");

//        reader parasiau atskira metoda, kuri po to dar naudojau. Pagal salyga ji reikejo rasyti cia.

        AlgoritmaiKestutis.printStars(AlgoritmaiKestutis.reader());
    }
}
