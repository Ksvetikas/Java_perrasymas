package kontrolinukas;

public class TestAlgoritmaiVardas {

    public static void main(String[] args) {

        int[] arr = {1, 2, 3, 4, 5};

        int[] arr2 = {1, 2, 3, 4, 5, 6};

        System.out.println("print() test.");
        AlgoritmaiKestutis.print(arr);

        System.out.println("");

        System.out.println("arrToString() test.");
        System.out.println( AlgoritmaiKestutis.arrayToString(arr) );

        System.out.println("");
        System.out.println("contains() test.");
        System.out.println("Tikrinamas masyvas arr. Ar masyve yra nurodomas skaicius.");
        int n = AlgoritmaiKestutis.reader();
        System.out.println( AlgoritmaiKestutis.contains(arr, n) );

        System.out.println("");
        System.out.println("equals() test.");
        System.out.println( AlgoritmaiKestutis.equals(arr, arr2) );


    }
}
