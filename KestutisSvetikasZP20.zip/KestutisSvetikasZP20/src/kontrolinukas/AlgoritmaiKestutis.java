package kontrolinukas;

import java.util.Arrays;
import java.util.Scanner;

public class AlgoritmaiKestutis {

        public static int reader() {

            Scanner rd = new Scanner(System.in);

            System.out.println("Iveskite skaiciu: ");

            int n = rd.nextInt();

            rd.close();

            return n;
        }

        public static void printArray(int []arr) {

            System.out.print(Arrays.toString(arr));

        }

        //    U01
        public static void printStars(int stars) {

            for (int i = 0; i < stars; i++) {
                System.out.print("*");
            }

        }


        //    U02
        public static void masyvai2() {

            int [] arr1 = new int [5];

            int [] arr2 = new int [5];

            int [] arr3 = new int [5];

            Scanner rd = new Scanner(System.in);

            System.out.println("Iveskite pirmojo maksyvo elementu reiksmes.");
            for (int i = 0 ; i < arr1.length; i++) {

//            int n = reader(); Kazkodel strigo reader metodas cikle. Neieskojau bedos, butu ilgai uztruke.
//            Sekancios dvi eilutes tiesiog nukopijuotos is reader metodo. Kitur reader metodas veikia.

                System.out.println("Iveskite skaiciu: ");

                int n = rd.nextInt();

                arr1[i] = n;

            }


            System.out.println("Iveskite antrojo maksyvo elementu reiksmes.");
            for (int i = 0 ; i < arr2.length; i++) {

//            int n = reader();

                System.out.println("Iveskite skaiciu: ");

                int n = rd.nextInt();
                arr2[i] = n;
            }

            for (int i = 0; i < 5 ; i++) {
                arr3[i] = arr1[i] * arr2[i];
            }

            System.out.println("Pirmojo masyvo elementu reiksmes:");
            printArray(arr1);

            System.out.println("");
            System.out.println("Antrojo masyvo elementu reiksmes:");
            printArray(arr2);

            System.out.println("");
            System.out.println("Treciojo masyvo elementu reiksmes:");
            printArray(arr3);

            rd.close();

        }





    public static void print(int[] arr) {

        printArray(arr);

    }

    public static String arrayToString(int []arr) {

        return Arrays.toString(arr);

    }

    public  static  boolean contains(int [] array, int key) {

        int count = 0;

        for (int i = 0; i < array.length; i++) {

            if(array[i] == key){
                count++;
            }
        }

        if (count == 0){
            return false;
        }else {
            return true;
        }
    }

    public static boolean equals(int[] array1, int[] array2) {

        Boolean value = new Boolean(null);

        if (!(array1.length == array2.length)){

            return false;
        }else {

             for (int i = 0; i < array1.length; i++) {
                 if (!(array1[i] == array2[i])) {
                     value = false;
                 }else {
                     value = true;
                 }
             }

             return value;
        }
    }
}
